SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE `feedback` (
  `feedback_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `phone_number` (`phone_number`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `vehicles` (
  `vehicle_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `license_plate` varchar(20) NOT NULL,
  `model` varchar(50) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`vehicle_id`),
  UNIQUE KEY `license_plate` (`license_plate`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('6','1','jdoe@example.com','Great system! Easy to use.','2025-04-30 16:01:46');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('7','2','asmith@example.com','Found a small bug when uploading vehicle info.','2025-04-30 16:01:46');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('9','4','cchen@example.com','Can you add more parking zones in the app?','2025-04-30 16:01:46');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('10','5','dlee@example.com','The map loads slowly on my phone.','2025-04-30 16:01:46');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('11',null,'test@example.com','这是我的反馈内容','2025-05-04 21:27:23');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('12','1','jdoe@example.com','1','2025-05-21 21:01:14');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('13','1','jdoe@example.com','1','2025-05-21 21:01:20');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('14','1','jdoe@example.com','1','2025-05-21 21:01:43');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('15',null,'jdoe@example.com','1','2025-05-21 21:02:49');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('16','1','jdoe@example.com','1','2025-05-21 21:07:51');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('17','1','jdoe@example.com','2','2025-05-21 21:11:22');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('18',null,'jdoe@example.com','1','2025-05-21 21:17:21');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('19',null,'jdoe@example.com','1','2025-05-21 21:17:39');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('20','1','jdoe@example.com','测试','2025-05-21 21:20:05');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('21',null,'jdoe@example.com','测试2','2025-05-21 21:22:09');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('22',null,'jdoe@example.com','2','2025-06-11 23:39:34');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('23','1','jdoe@example.com','3','2025-06-11 23:41:44');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('24',null,'jdoe@example.com','2','2025-06-11 23:57:55');
INSERT INTO `feedback` (`feedback_id`, `user_id`, `email`, `message`, `submitted_at`) VALUES ('25',null,'jdoe@example.com','1','2025-06-12 00:10:03');

INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('1','jdoe','123456','John Doe','12345678904','jdoe@example.com','2025-04-30 16:01:45');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('2','Adam','password1','Alice Smith','23456789012','asmith@example.com','2025-04-30 16:01:45');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('3','bwhite123','bwhite','Bob White','34567890123','bwhite@example.com','2025-04-30 16:01:45');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('4','cchen','114514','Chen Chen','45678901234','cchen@example.com','2025-04-30 16:01:45');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('5','dlee','15543','David Lee','56789012345','dlee@example.com','2025-04-30 16:01:45');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('6','newuser1','newpassword1','New User 1','12345678900','newuser1@example.com','2025-05-02 00:38:00');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('7','testuser1','testpass1','newuser2','18888888888','test1@example.com','2025-05-04 18:08:34');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('8','testuser','123456','Test User','1234567890','test@example.com','2025-05-11 22:33:25');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('9','123456789','123456789','ojhgff','12345678999','258@qq.com','2025-05-12 10:53:33');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('11','123456','123456','123','13191568655','123@qq.com','2025-05-12 10:59:25');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('25','qaz','qaz','qaz','123456789123','qaz@qq.com','2025-05-12 11:16:39');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('30','123512','5255','stw','1577894561','521@qq.com','2025-05-12 11:25:13');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('31','789456','741','789456123','789456123','741@qq.com','2025-05-12 11:27:04');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('32','13561154','123789456','qwer','12345678965','qwe@qq.com','2025-05-12 11:31:18');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('33','wangerjun','wangerjun','wangerjun','wangerjun','wangerjun','2025-05-18 17:15:46');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('35','963258','9632587','qwertyu','123456987','9638527@qq.com','2025-05-21 17:41:05');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('36','stw123','stw1356115478','stw123','1356115478','stw123@qq.com','2025-05-21 17:42:54');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('73','yzc123','yzc123','yzc123456','1356115478123','yzc123@qq.com','2025-05-21 18:01:52');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('74','wang123','wang123','wej123','wang123','wej123@qq.com','2025-05-21 18:09:26');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('76','wej','wang123','wej','wqlalqo','wej123456789@qq.com','2025-05-21 18:10:33');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('77','nb','smxyzc6109','养养眼','+8613078085392','245575666@qq.com','2025-05-21 21:12:49');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('78','z.yang.23@student.scu.edu.au','123333','马嘉祺','+8613078085393','1812168202@qq.com','2025-05-21 21:23:09');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('79','橘子洲','123456','马嘉祺2','13078085393','808573d@insyt.org','2025-06-12 00:02:09');
INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `phone_number`, `email`, `created_at`) VALUES ('82','橘子洲1','123456','马嘉祺3','13078085394','181216820@qq.com','2025-06-12 00:13:32');

INSERT INTO `vehicles` (`vehicle_id`, `user_id`, `license_plate`, `model`, `color`, `created_at`) VALUES ('6','1','ABC123','Toyota Coroll','White','2025-04-30 16:01:46');
INSERT INTO `vehicles` (`vehicle_id`, `user_id`, `license_plate`, `model`, `color`, `created_at`) VALUES ('7','2','XYZ789','Honda Civic','Black','2025-04-30 16:01:46');
INSERT INTO `vehicles` (`vehicle_id`, `user_id`, `license_plate`, `model`, `color`, `created_at`) VALUES ('8','3','LMN456','Tesla Model 3','Red','2025-04-30 16:01:46');
INSERT INTO `vehicles` (`vehicle_id`, `user_id`, `license_plate`, `model`, `color`, `created_at`) VALUES ('9','4','JKL321','BMW X3','Blue','2025-04-30 16:01:46');
INSERT INTO `vehicles` (`vehicle_id`, `user_id`, `license_plate`, `model`, `color`, `created_at`) VALUES ('10','5','QWE987','Audi A4','Gray','2025-04-30 16:01:46');
INSERT INTO `vehicles` (`vehicle_id`, `user_id`, `license_plate`, `model`, `color`, `created_at`) VALUES ('11','6','GHI999','Hyundai Elantra','Green','2025-05-05 18:41:50');
INSERT INTO `vehicles` (`vehicle_id`, `user_id`, `license_plate`, `model`, `color`, `created_at`) VALUES ('12','8','XYZ987','Honda Civic','Red','2025-05-11 23:20:00');
INSERT INTO `vehicles` (`vehicle_id`, `user_id`, `license_plate`, `model`, `color`, `created_at`) VALUES ('21','1','ABC125','Toyota Corolla','White','2025-06-12 00:12:08');

